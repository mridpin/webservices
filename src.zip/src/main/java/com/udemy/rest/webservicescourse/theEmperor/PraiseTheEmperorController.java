package com.udemy.rest.webservicescourse.theEmperor;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PraiseTheEmperorController {

  @GetMapping(path = "/praiseTheEmperor")
  public String praiseTheEmperor(){
    return "The Emperor Protects";
  }

  @GetMapping(path = "/praiseTheEmperor/{name}")
  public PraiseTheEmperorBean praiseTheEmperor(@PathVariable String name){
    return new PraiseTheEmperorBean(String.format("Praise the Emperor, %s", name));
  }

  @GetMapping(path = "/praiseTheEmperorBean")
  public PraiseTheEmperorBean praiseTheEmperorBean(){
    return new PraiseTheEmperorBean("Praise the Emperor");
  }


}
