package com.udemy.rest.webservicescourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebservicesCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebservicesCourseApplication.class, args);
	}

}
