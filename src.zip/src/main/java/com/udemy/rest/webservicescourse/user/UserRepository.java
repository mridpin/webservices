package com.udemy.rest.webservicescourse.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class UserRepository {
    private static List<User> users = new ArrayList<>();
    Integer userCount = 4;

    static {
      users.add(new User(1, "Lion El Johnson", new Date()));
      users.add(new User(3, "Fulgrim", new Date()));
      users.add(new User(4, "Perturabo", new Date()));
    }

    public List<User> findAll() {
      List<User> users = this.users;
      return users;
    }

  public User findById(Integer id) {
    for (User user : users) {
      if (user.getId() == id) {
        return user;
      }
    }
    return null;
  }

  public User createUser(User user) {
    if (null != user) {
      user.setId(++userCount);
      users.add(user);
      return user;
    } else {
      return null;
    }
  }

}
